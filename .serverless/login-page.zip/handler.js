'use strict';

//
const handlers = require('./handlers');

// build
module.exports.buildLogin = (event, context, callback) =>
  handlers.buildHandler(event, context, (response) => {
    console.log(response);
    context.done(null, response);
  });

// updateView
module.exports.updateView = (event, context, callback) =>
  handlers.updateViewHandler(event, context, (response) => {
    console.log(response);
    context.done(null, response);
  });

// authCallback
module.exports.authCallback = (event, context, callback) =>
  handlers.authCallbackHandler(event, context, (response) => {
    console.log(response);
    context.done(null, response);
  });
