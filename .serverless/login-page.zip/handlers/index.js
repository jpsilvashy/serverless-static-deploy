'use strict';

exports = module.exports = {
  buildHandler:      require('./buildHandler'),
  updateViewHandler: require('./updateViewHandler'),
};
