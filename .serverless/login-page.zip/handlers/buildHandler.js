'use strict';

// Gulp deps
var fs       = require('fs');
var jsonfile = require('jsonfile');

// lib
var lib = require('../lib');

// Handler
function buildHandler(event, context, callback) {
  console.log('event', event);

  lib.gulpTasks('release', '/tmp/dist', function(sessionID) {
    // build paths to show in response
    var releasePath = 'https://render-dev.gauge.io/' + sessionID;

    // build response
    var response = {
      session: sessionID,
          url: releasePath + '/index.html',
    };

    callback(response)
  });

  // // Build into the tmp dir on the lambda
  // lib.build('/tmp/dist', function(releaseId) {
  //   console.log('releaseId', releaseId);
  //
  //   // build paths to show in response
  //   var releasePath = 'https://render-dev.gauge.io/' + releaseId;
  //
  //   // build response
  //   var response = {
  //      release: releaseId,
  //          url: releasePath + '/index.html',
  //      package: releasePath + '/package.tar.gz',
  //        debug: releasePath + '/debug.html',
  //     schedule: releasePath + '/schedule.html'
  //   };
  //
  //   callback(response);
  // });

};


// Exports
exports = module.exports = buildHandler;
