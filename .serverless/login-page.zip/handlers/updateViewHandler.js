'use strict';

// Handler
function updateViewHandler(event, context, callback) {
  var requestId = uuid.v4();

  var response = {
    requestId: requestId
  }

  callback(null, response);
}

// Exports
exports = module.exports = updateViewHandler;
