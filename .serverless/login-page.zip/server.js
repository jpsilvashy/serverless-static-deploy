// Load display view client
var api = require('./app/server/api');
var path = require('path');

// Send in path to config, or use local
if (process.env.CONFIG) {
  var config = require(process.env.CONFIG)
} else {
  var config = require(__dirname + '/config')
}

// Start API
api.start(config);
