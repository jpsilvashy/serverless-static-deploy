#!/usr/bin/env node

// Export the API
module.exports = require('./app/server/api');
