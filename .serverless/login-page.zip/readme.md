Display Client
==============

This NPM package is used to create display integrations.

## Installation

  npm install display-view-client --save

## Usage

  var displayClient = require('display-view-client')
  displayClient.start();

## Tests

  npm test

## Contributing

In lieu of a formal styleguide, take care to maintain the existing coding style.
Add unit tests for any new or changed functionality. Lint and test your code.

## Release History

* 0.1.0 Initial release
